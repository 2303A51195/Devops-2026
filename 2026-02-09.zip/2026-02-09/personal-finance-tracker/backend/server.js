const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

let income = 75000;
let expenses = 42000;

app.get("/api/dashboard", (req, res) => {
  const randomIncome = Math.floor(Math.random() * 5000);
  const randomExpense = Math.floor(Math.random() * 3000);

  income += randomIncome;
  expenses += randomExpense;

  res.json({
    totalIncome: income,
    totalExpenses: expenses,
    balance: income - expenses,
    lastUpdated: new Date().toLocaleString(),
  });
});

app.listen(PORT, () => {
  console.log(` Backend server running at http://localhost:${PORT}`);
});