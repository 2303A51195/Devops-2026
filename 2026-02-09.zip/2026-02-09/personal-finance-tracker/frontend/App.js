import Dashboard from './Dashboard'; // Import the Dashboard component

const App = () => {
  return (
    <div className="App">
      <Dashboard />  {/* Use the Dashboard component here */}
    </div>
  );
};

export default App;