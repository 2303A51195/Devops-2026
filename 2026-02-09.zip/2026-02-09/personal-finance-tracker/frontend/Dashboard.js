import React, { useEffect, useState } from "react";
import "./App.css"; 

function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch("http://localhost:5000/api/dashboard");
      if (!response.ok) {
        throw new Error("Failed to fetch dashboard data");
      }

      const result = await response.json();
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amount);
  };

  if (loading) return <p className="status loading">Loading dashboard...</p>;
  if (error) return <p className="status error">{error}</p>;

  const balance = data.totalIncome - data.totalExpenses;

  return (
    <div className="dashboard">
      <h2>Personal Finance Dashboard</h2>

      <div className="cards">
        <div className="card income">
          <h3>Total Income</h3>
          <p>{formatCurrency(data.totalIncome)}</p>
        </div>

        <div className="card expense">
          <h3>Total Expenses</h3>
          <p>{formatCurrency(data.totalExpenses)}</p>
        </div>

        <div className="card balance">
          <h3>Balance</h3>
          <p>{formatCurrency(balance)}</p>
        </div>
      </div>

      <button className="refresh-btn" onClick={fetchDashboardData}>
        🔄 Refresh
      </button>
    </div>
  );
}

export default Dashboard;
